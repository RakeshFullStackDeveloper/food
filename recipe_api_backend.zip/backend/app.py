from fastapi import FastAPI, Depends, Query
from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
import crud, schemas

Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/api/recipes")
def read_recipes(page: int = 1, limit: int = 10, db: Session = Depends(get_db)):
    skip = (page - 1) * limit
    recipes = crud.get_recipes(db, skip=skip, limit=limit)
    total = crud.count_recipes(db)
    return {"page": page, "limit": limit, "total": total, "data": recipes}

@app.get("/api/recipes/search")
def search_recipes(
    title: str = None,
    cuisine: str = None,
    rating: float = Query(None),
    total_time: int = Query(None),
    calories: int = Query(None),
    db: Session = Depends(get_db)
):
    recipes = crud.search_recipes(db, title=title, cuisine=cuisine, rating=rating, total_time=total_time, calories=calories)
    return {"data": recipes}
