from sqlalchemy.orm import Session
from models import Recipe
from sqlalchemy import Integer

def get_recipes(db: Session, skip: int, limit: int):
    return db.query(Recipe).order_by(Recipe.rating.desc()).offset(skip).limit(limit).all()

def count_recipes(db: Session):
    return db.query(Recipe).count()

def search_recipes(db: Session, title=None, cuisine=None, rating=None, total_time=None, calories=None):
    query = db.query(Recipe)
    if title:
        query = query.filter(Recipe.title.ilike(f"%{title}%"))
    if cuisine:
        query = query.filter(Recipe.cuisine == cuisine)
    if rating:
        query = query.filter(Recipe.rating >= float(rating))
    if total_time:
        query = query.filter(Recipe.total_time <= int(total_time))
    if calories:
        query = query.filter((Recipe.nutrients['calories'].astext).cast(Integer) <= int(calories))
    return query.all()
