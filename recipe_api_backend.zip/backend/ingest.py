import json
from database import SessionLocal, engine, Base
from models import Recipe

Base.metadata.create_all(bind=engine)
db = SessionLocal()

with open("recipes.json", "r") as f:
    data = json.load(f)

for recipe in data:
    def safe_num(val):
        try:
            return int(val)
        except:
            try:
                return float(val)
            except:
                return None

    new_recipe = Recipe(
        cuisine=recipe.get("cuisine"),
        title=recipe.get("title"),
        rating=safe_num(recipe.get("rating")),
        prep_time=safe_num(recipe.get("prep_time")),
        cook_time=safe_num(recipe.get("cook_time")),
        total_time=safe_num(recipe.get("total_time")),
        description=recipe.get("description"),
        nutrients=recipe.get("nutrients"),
        serves=recipe.get("serves")
    )
    db.add(new_recipe)

db.commit()
db.close()
